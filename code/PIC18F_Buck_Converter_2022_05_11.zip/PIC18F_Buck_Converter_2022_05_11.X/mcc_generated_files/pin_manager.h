/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC18F13K22
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.31 and above
        MPLAB 	          :  MPLAB X 5.45	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set VFB aliases
#define VFB_TRIS                 TRISAbits.TRISA4
#define VFB_LAT                  LATAbits.LATA4
#define VFB_PORT                 PORTAbits.RA4
#define VFB_WPU                  WPUAbits.WPUA4
#define VFB_ANS                  ANSELbits.ANS3
#define VFB_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define VFB_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define VFB_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define VFB_GetValue()           PORTAbits.RA4
#define VFB_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define VFB_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define VFB_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define VFB_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define VFB_SetAnalogMode()      do { ANSELbits.ANS3 = 1; } while(0)
#define VFB_SetDigitalMode()     do { ANSELbits.ANS3 = 0; } while(0)

// get/set RB7 procedures
#define RB7_SetHigh()            do { LATBbits.LATB7 = 1; } while(0)
#define RB7_SetLow()             do { LATBbits.LATB7 = 0; } while(0)
#define RB7_Toggle()             do { LATBbits.LATB7 = ~LATBbits.LATB7; } while(0)
#define RB7_GetValue()              PORTBbits.RB7
#define RB7_SetDigitalInput()    do { TRISBbits.TRISB7 = 1; } while(0)
#define RB7_SetDigitalOutput()   do { TRISBbits.TRISB7 = 0; } while(0)
#define RB7_SetPullup()             do { WPUBbits.WPUB7 = 1; } while(0)
#define RB7_ResetPullup()           do { WPUBbits.WPUB7 = 0; } while(0)

// get/set IFB aliases
#define IFB_TRIS                 TRISCbits.TRISC0
#define IFB_LAT                  LATCbits.LATC0
#define IFB_PORT                 PORTCbits.RC0
#define IFB_ANS                  ANSELbits.ANS4
#define IFB_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define IFB_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define IFB_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define IFB_GetValue()           PORTCbits.RC0
#define IFB_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define IFB_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define IFB_SetAnalogMode()      do { ANSELbits.ANS4 = 1; } while(0)
#define IFB_SetDigitalMode()     do { ANSELbits.ANS4 = 0; } while(0)

// get/set REDLED aliases
#define REDLED_TRIS                 TRISCbits.TRISC3
#define REDLED_LAT                  LATCbits.LATC3
#define REDLED_PORT                 PORTCbits.RC3
#define REDLED_ANS                  ANSELbits.ANS7
#define REDLED_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define REDLED_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define REDLED_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define REDLED_GetValue()           PORTCbits.RC3
#define REDLED_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define REDLED_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define REDLED_SetAnalogMode()      do { ANSELbits.ANS7 = 1; } while(0)
#define REDLED_SetDigitalMode()     do { ANSELbits.ANS7 = 0; } while(0)

// get/set RC5 procedures
#define RC5_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define RC5_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define RC5_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define RC5_GetValue()              PORTCbits.RC5
#define RC5_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define RC5_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)

// get/set GREENLED aliases
#define GREENLED_TRIS                 TRISCbits.TRISC6
#define GREENLED_LAT                  LATCbits.LATC6
#define GREENLED_PORT                 PORTCbits.RC6
#define GREENLED_ANS                  ANSELHbits.ANS8
#define GREENLED_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define GREENLED_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define GREENLED_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define GREENLED_GetValue()           PORTCbits.RC6
#define GREENLED_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define GREENLED_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define GREENLED_SetAnalogMode()      do { ANSELHbits.ANS8 = 1; } while(0)
#define GREENLED_SetDigitalMode()     do { ANSELHbits.ANS8 = 0; } while(0)

// get/set BLUELED aliases
#define BLUELED_TRIS                 TRISCbits.TRISC7
#define BLUELED_LAT                  LATCbits.LATC7
#define BLUELED_PORT                 PORTCbits.RC7
#define BLUELED_ANS                  ANSELHbits.ANS9
#define BLUELED_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define BLUELED_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define BLUELED_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define BLUELED_GetValue()           PORTCbits.RC7
#define BLUELED_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define BLUELED_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define BLUELED_SetAnalogMode()      do { ANSELHbits.ANS9 = 1; } while(0)
#define BLUELED_SetDigitalMode()     do { ANSELHbits.ANS9 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/