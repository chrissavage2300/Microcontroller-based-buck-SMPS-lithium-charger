/**
2022_06_01_A
 * Buck Lithium Charger
 * PIC:PIC18F13k22
 * This program controls the current and voltage mode to properly charge
 * a lithium ion battery. The output current is currently set at 1A
 * Current set points are as follows:
 * 125 = 250mA
 * 270 = 500mA
 * 540 = 1000mA
 * Higher currents are possible but have not been tested. 
 * Note: 5V input only. 
*/



#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/epwm1.h"
#define _XTAL_FREQ 64000000

#define CurrentSetpoint 270 //
#define VoltageSetpoint 839 //4.20V

#define PWM_min 73 



unsigned int ADC_Result;
unsigned int Raw_VFB;
unsigned int Raw_IFB;

unsigned int increment_Value;
unsigned int Current_Mode=0;
unsigned int Voltage_mode=0;
extern unsigned int SecondsTime;
extern unsigned int BatteryDone;
unsigned int BatteryEmpty;

void Current_Control_loop(void){    //this loop controls the constant current mode
Raw_IFB=ADC1_GetConversion (IFB);
    if(increment_Value < PWM_min) increment_Value = PWM_min;
    if(Raw_IFB<=CurrentSetpoint)increment_Value++;
    if(Raw_IFB>=CurrentSetpoint)increment_Value--;
EPWM1_LoadDutyValue(increment_Value); 
    
}
void Voltage_Control_loop(void){    //this loop controls constant voltage mode
Raw_VFB=ADC1_GetConversion (VFB);
    //if(Raw_VFB < VoltageSetpoint) increment_Value = 500;
    if(Raw_VFB<=VoltageSetpoint)increment_Value++;
    if(Raw_VFB>=VoltageSetpoint)increment_Value--;
EPWM1_LoadDutyValue(increment_Value); 
    
}


/*
                         Main application
 */
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    TMR0_Initialize();
    TMR0_StopTimer();

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();


    increment_Value=0;
    Current_Mode=0;
    Voltage_mode=0;
    EPWM1_LoadDutyValue(0);
    __delay_ms(500);
    BLUELED_SetLow();
    GREENLED_SetLow();
    printf("\rBuck Lithium Charger 2022_06_04_A\r\n");
    while (1)
    {
        //35uS cycle time
        //first, power the FET OFF and check to see if there is a battery present.
        Raw_VFB=ADC1_GetConversion (VFB); //measure battery
        Raw_IFB=ADC1_GetConversion (IFB); //measure current. This is only for the uart string
        printf("Voltage: %u \r\n", Raw_VFB);
        printf("Current: %u \r\n", Raw_IFB);
        
        if (Raw_VFB<=570){  //Error check loop. No battery.
           REDLED_SetHigh();
           BLUELED_SetLow();
           GREENLED_SetLow();
           //make sure flags are cleared
           Current_Mode=0;
           Voltage_mode=0;
           EPWM1_LoadDutyValue(0);//Turn off PWM circuit
           //make sure battery done flag is cleared and timer is off
           BatteryDone=0;
           TMR0_StopTimer();    //had issues with the timer running so this is needed
           INTERRUPT_PeripheralInterruptDisable();  //had issues with the timer running so this is needed
           BatteryEmpty=1;
           printf("\rWarning! No Battery!\r\n");
        };//end error check
        
        if ((Raw_VFB >=600) && (Raw_VFB <=830)){//check to see if battery is between 3V and 4.15V. 
            Current_Mode=1;
            Voltage_mode=0;
            INTERRUPT_PeripheralInterruptDisable(); //had issues with the timer running so this is needed
            printf("\rCurrent Mode On\r\n");

        };//end current mode check
 
        //check to see if battery is between 4.15V and 4.20V. Make sure timer is not on
        //this should ensure it doesn't pop back into voltage mode once done.
 
       if (BatteryDone==0) {
            if ((Raw_VFB>830) && (Raw_VFB <=840)){ 
                Voltage_mode=1;                                              
                Current_Mode=0;
                INTERRUPT_PeripheralInterruptEnable();  //re-enable the timer interrupt
                printf("\rVoltage Mode On\r\n");
                
            };//end voltage mode check
       };//end battery check
        
        if ((Current_Mode==1) && (Voltage_mode==0)){  //turn on current mode. 
            BLUELED_SetHigh();                         
            REDLED_SetLow();
            GREENLED_SetLow();
            Current_Control_loop();        
        };//end current mode
        
        if ((Voltage_mode==1)&&(BatteryDone==0)){//turn on voltage mode
            INTERRUPT_PeripheralInterruptEnable();
            TMR0_StartTimer();
            REDLED_SetLow();
            BLUELED_SetLow();
            Voltage_Control_loop();
        };//end voltage mode    
        
        //if the battery is done OR current is 1C/10 and its in voltage mode, end charging
        if ((BatteryDone==1)|| ((Raw_IFB<=50)&&(Voltage_mode==1))){
            Voltage_mode=0;
            Current_Mode=0;
            GREENLED_SetHigh(); //set LED high
            REDLED_SetLow();
            BLUELED_SetLow();
            SecondsTime=0;      //reset
            EPWM1_LoadDutyValue(0);        
            TMR0_StopTimer();   //stop timer
            printf("\rBattery Charged.\r\n");
        
        };//end battery done loop
        
        
        
    

        
     
      
    }
}
/**
 End of File
*/